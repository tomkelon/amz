var hostname = window.location.hostname;
var uniqueId = "amazon-search-" + chrome.runtime.id;

var validDomains = {
  "www.amazon.com": "english",
  "www.amazon.co.uk": "english",
  "www.amazon.com.au": "english",
  "www.amazon.ca": "canadian",
  "www.amazon.es": "estonia",
  "www.amazon.it": "italian",
  "www.amazon.de": "germani",
  "www.amazon.fr": "french",
};

/**
 * Create and download excel file
 * @param {*} productDetails
 */
function createExcelFile(keywords) {
  var createXLSLFormatObj = [];

  /* XLS Head Columns */
  var xlsHeader = ["Keywords"];

  console.log("before", keywords);
  /* XLS Rows Data */
  var xlsRows = Object.keys(keywords).map(function (key) {
    return {
      Keywords: keywords[key].value,
    };
  });
  console.log("after", xlsRows);

  createXLSLFormatObj.push(xlsHeader);
  $.each(xlsRows, function (index, value) {
    var innerRowData = [];
    $.each(value, function (ind, val) {
      innerRowData.push(val);
    });
    createXLSLFormatObj.push(innerRowData);
  });

  /* File Name */
  var filename = "keywords.xlsx";

  /* Sheet Name */
  var ws_name = "keywords";

  if (typeof console !== "undefined") console.log(new Date());
  var wb = XLSX.utils.book_new(),
    ws = XLSX.utils.aoa_to_sheet(createXLSLFormatObj);

  /* Add worksheet to workbook */
  XLSX.utils.book_append_sheet(wb, ws, ws_name);

  /* Write workbook and Download */
  if (typeof console !== "undefined") console.log(new Date());
  XLSX.writeFile(wb, filename);
  if (typeof console !== "undefined") console.log(new Date());
}

/**
 * Render analysis table
 * @param {*} avgBSR
 * @param {*} nicheScore
 * @param {*} avgReviews
 * @param {*} avgPrice
 */
function renderList(firstSuggestions, recommendedKeywords) {
  console.log("renderlist");
  let style = document.createElement("style");
  let stylePrefix = chrome.runtime.id;
  let searchedText = $("#twotabsearchtextbox").val().trim();
  let beforeItems = recommendedKeywords.filter(
    (item) => item.value.indexOf(searchedText) > 0
  );
  let afterItems = recommendedKeywords.filter(
    (item) => item.value.indexOf(searchedText) === 0
  );
  style.innerText = `\
    #${stylePrefix}-list-wrapper {\
      position: absolute;\
      width: 99%;\
      transform: translate(-50%, 0);\
      left: 50%;\
      z-index: 999999999999;\
      top: -11px;\
      overflow: visible!important;\
      background: #fff;\
      border: 1px solid #bbb;\
      box-sizing: border-box;\
      -moz-box-sizing: border-box;\
      -webkit-box-sizing: border-box;\
      margin: 0;\
      -webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,.13);\
      -moz-box-shadow: 0 2px 4px 0 rgba(0,0,0,.13);\
      box-shadow: 0 2px 4px 0 rgba(0,0,0,.13);\
      -ms-user-select: none;\
      zoom: 1;\
      font-size: 13px;\
      font-family: inherit;\
      line-height: normal;\
      min-height: 450px;\
    }\
\
    #${stylePrefix}-list-wrapper ul {\
      margin: 0;\
      display: flex;\
      flex-wrap: wrap;\
    }\
\
    #${stylePrefix}-list-wrapper ul li {\
      list-style: none;\
      cursor: pointer;\
      width: 25%;\
      cursor: pointer;\
    }\
\
    #${stylePrefix}-list-wrapper ul li a {\
      font-family: "Amazon Ember",Arial,sans-serif;\
      font-size: 16px;\
      color: #000;\
      padding: 8px 10px;\
      font-size: 16px;\
      font-family: "Amazon Ember";\
      cursor: pointer;\
      width: 100%;\
      display: table;\
      text-decoration: none;\
      cursor: pointer;\
    }\

    #${stylePrefix}-list-wrapper ul li:hover a {\
      background-color: #eee;\
    }\
\
    #${stylePrefix}-list-wrapper table {\

    }\
\
    #${stylePrefix}-list-wrapper table tr td {\
      vertical-align: middle;\
      background-color: #24282d;\
      padding: 9px 13px;\
      text-align: center;\
      line-height: 2.5;\
    }\

    #${stylePrefix}-first-suggestions {\
      border: 1px solid #ddd;\
      padding: 25px 0;\
      margin-bottom: 10px;\
      position: relative;\
    }\

    #${stylePrefix}-first-suggestions span{\
      position: absolute;\
      top: 0;\
      background: #ddd;\
      padding: 4px 10px;\
      border-bottom-right-radius: 5px;\
    }\
\
    #${stylePrefix}-additional-suggestions {\
      border: 1px solid #ddd;\
      padding: 25px 0;\
      margin-bottom: 10px;\
      position: relative;\
    }\
\
    #${stylePrefix}-additional-suggestions span {\
      position: absolute;\
      top: 0;\
      background: #ddd;\
      padding: 4px 10px;\
      border-bottom-right-radius: 5px;\
    }\
\
		.${stylePrefix}-h5 {\
			font-size: 16px;
			margin-left: 15px;\
			display: inline-block;\
    }\
\
		.${stylePrefix}-h5-container {\
			border: 1px solid #FDE89E;\
			border-radius: 10px;\
			width: 270px;\
			height: 70px;\
			line-height: 70px\
    }\
\
		.${stylePrefix}-logo-container {\
			width: 270px;\
			height: 70px;\
    }\

		.${stylePrefix}-h5-img {\
			width: 23px;\
			margin: 20px 10px;\
    }\
  `;
  document.getElementsByTagName("head")[0].appendChild(style);

  if (document.getElementById(`${stylePrefix}-list-wrapper`)) {
    document.getElementById(`${stylePrefix}-list-wrapper`).remove();
  }

  $("#nav-flyout-iss-anchor").prepend(`
    <div id="${stylePrefix}-list-wrapper">
				<table>
          <tr>
            <td style="border: 1px solid #23282d; background-color: rgb(35, 40, 45);">
							<div class="${stylePrefix}-logo-container">
										<img src="chrome-extension://${
                      chrome.runtime.id
                    }/images/publishing.png" style="margin: 20px 0px;" width="300px">
								</div>

						</td>
						<td style="text-align: left; border: 1px solid #23282d; background-color: rgb(35, 40, 45);">

							<div class="${stylePrefix}-h5-container">
									<a href="javascript: void(0)" id="download_excel_file_${
                    chrome.runtime.id
                  }" style="color: white;">

										<h5 style="line-" class="${stylePrefix}-h5">Download All Suggestions</h5>
											<img src="chrome-extension://${
                        chrome.runtime.id
                      }/images/Download_icon.png" class="${stylePrefix}-h5-img">
									</a>
							</div>

						</td>

						<td style="text-align: left;border: 1px solid #23282d;background-color: rgb(35, 40, 45);">
							<div class="${stylePrefix}-h5-container">
									<a href="https://www.facebook.com/groups/2690865597847008" style="color: white;">
										<h5 class="${stylePrefix}-h5">Join Facebook Group</h5>

										<img src="chrome-extension://${
                      chrome.runtime.id
                    }/images/right-arrow.png" class="${stylePrefix}-h5-img">

									</a>
							</div>

						</td>

						<td style="text-align: left;border: 1px solid #23282d;background-color: rgb(35, 40, 45);">
							<div class="${stylePrefix}-h5-container">
										<a href="https://chrome.google.com/webstore/detail/kdp-amazon-bsr-keyword-re/eefljgmhgaidffapnppcmmafobefjece?hl=en-US" style="color: white;">
										<h5 class="${stylePrefix}-h5">More Free Tools</h5>

										<img src="chrome-extension://${
                      chrome.runtime.id
                    }/images/right-arrow.png" class="${stylePrefix}-h5-img">

									</a>
							</div>
						</td>

						<td style="text-align: left;border: 1px solid #23282d;background-color: rgb(35, 40, 45);">
							<div class="${stylePrefix}-h5-container" style="background-color: red;">
										<a href="https://www.youtube.com/channel/UCkOTYGNYxS6jq7JT3Fk5NEQ" style="color: white;">
										<h5 class="${stylePrefix}-h5">New Tutorial Video!</h5>

										<img src="chrome-extension://${
                      chrome.runtime.id
                    }/images/right-arrow.png" class="${stylePrefix}-h5-img">

									</a>
							</div>
						</td>
          </tr>
        </table>
        <ul id="${stylePrefix}-first-suggestions">
          <span>Primary Amazon Suggestions</span>
          ${Object.keys(firstSuggestions)
            .map((key) => {
              const item = firstSuggestions[key];
              return `<li><a href="#" onClick="(function(){document.getElementById('${stylePrefix}-list-wrapper').remove(); window.location = '${item.link}';return false;})();return false;">${item.value}</a></li>`;
            })
            .join("")}
        </ul>
				<ul id="${stylePrefix}-first-suggestions">
          <span>Before Keywords Suggestions</span>
          ${Object.keys(beforeItems)
            .map((key) => {
              const item = beforeItems[key];
              return `<li><a href="#" onClick="(function(){document.getElementById('${stylePrefix}-list-wrapper').remove(); window.location = '${item.link}';return false;})();return false;">${item.value}</a></li>`;
            })
            .join("")}
        </ul>
        <ul id="${stylePrefix}-additional-suggestions">
            <span>Additional Amazon Suggestions</span>
          ${Object.keys(afterItems)
            .map((key) => {
              const item = afterItems[key];
              return `<li><a href="#" onClick="(function(){document.getElementById('${stylePrefix}-list-wrapper').remove(); window.location = '${item.link}';return false;})();return false;">${item.value}</a></li>`;
            })
            .join("")}
        </ul>

    </div>
  `);

  $("#download_excel_file_" + chrome.runtime.id).click(function () {
    createExcelFile([...firstSuggestions, ...recommendedKeywords]);
  });

  $(document).click(function (event) {
    var $target = $(event.target);
    if (
      !$target.closest(`#${stylePrefix}-list-wrapper`).length &&
      $(`#${stylePrefix}-list-wrapper`).is(":visible")
    ) {
      $(`#${stylePrefix}-list-wrapper`).hide();
    }
  });
}

/**
 * Get variables from page
 * @param {*} variables
 */
function retrieveWindowVariables(variables) {
  var ret = {};

  var scriptContent = "";
  for (var i = 0; i < variables.length; i++) {
    var currVariable = variables[i];
    scriptContent +=
      "if (typeof " +
      currVariable +
      " !== 'undefined') document.getElementsByTagName('body')[0].setAttribute('tmp_" +
      currVariable +
      "', " +
      currVariable +
      ");\n";
  }

  var script = document.createElement("script");
  script.id = "tmpScript";
  script.appendChild(document.createTextNode(scriptContent));
  (document.body || document.head || document.documentElement).appendChild(
    script
  );

  for (var i = 0; i < variables.length; i++) {
    var currVariable = variables[i];
    ret[currVariable] = document
      .getElementsByTagName("body")[0]
      .getAttribute("tmp_" + currVariable);
    document
      .getElementsByTagName("body")[0]
      .removeAttribute("tmp_" + currVariable);
  }

  document.getElementById("tmpScript").remove();

  return ret;
}

function getURLParameter(url, name) {
  return (RegExp(name + "=" + "(.+?)(&|$)").exec(url) || [, null])[1];
}

/**
 * Render analysis table
 */
function renderAnalysisTable() {
  // Check domain hostname
  if (!Object.keys(validDomains).includes(hostname)) {
    return;
  }

  chrome.storage.local.get(uniqueId + "_isEnable", function (data) {
    if (
      data[uniqueId + "_isEnable"] !== undefined &&
      (data[uniqueId + "_isEnable"] == "false" ||
        data[uniqueId + "_isEnable"] == false)
    ) {
      return;
    }

    // console.log("test", data[uniqueId + "_isEnable"]);

    var timer;
    $("#twotabsearchtextbox").on("keyup", function () {
      var searchedText = $(this).val().trim();
      console.log("twotabsearchtextbox");
      console.log(searchedText);

      clearInterval(timer);
      timer = setTimeout(function () {
        console.log("User finished typing !!", searchedText);

        let keywords = [];
        let keywordsElemenets = $(
          "#nav-flyout-searchAjax #suggestions-template #suggestions div"
        );
        // let keywordsElemenets = $(
        //   "#nav-flyout-searchAjax .s-suggestion-container .s-suggestion"
        // );
        if (!keywordsElemenets.length) {
          keywordsElemenets = $(
            "#nav-flyout-searchAjax .s-suggestion-container .s-suggestion"
          );
        }
        for (var i = 0; i < keywordsElemenets.length; ++i) {
          let keywordElement = keywordsElemenets[i];
          // var linkEl = $(keywordElement)
          //     .eq(0)
          //     .hasClass("s-suggestion-link-template");
          //   // hrefSrc;
          // if (linkEl)
          //   hrefSrc = $(keywordElement).eq(0).find("a").eq(0).attr("href");
          // const keyword = linkEl
          //   ? getURLParameter(hrefSrc, "k").replace("+", " ")
          //   : $(keywordElement).data("keyword");
          const keyword = $(keywordElement).text();
          // const crid = linkEl
          //   ? getURLParameter(hrefSrc, "crid")
          //   : $(keywordElement).data("crid");
          // const refTag = linkEl
          //   ? getURLParameter(hrefSrc, "ref")
          //   : $(keywordElement).data("reftag");

          console.log(keywords);
          console.log(keyword);

          if (keywords.filter((item) => item.value == keyword).length <= 0) {
            // console.log(keyword);
            keywords.push({
              value: keyword,
              link: `https://${hostname}/s?k=${keyword.replace(/ /g, "+")}`,
              // link: `https://${hostname}/s?k=${keyword.replace(
              //   / /g,
              //   "+"
              // )}&crid=${crid}&sprefix=${searchedText.replace(
              //   / /g,
              //   "+"
              // )}&ref=${refTag}`,
            });
          }
        }

        console.log("keywords", keywords);
        if (keywords.length > 0) {
          let promises = [];
          let recommendedKeywords = [];
          var variables = retrieveWindowVariables([
            "ue_mid",
            "ue_id",
            "ue_sid",
          ]);

          for (let i = 0; i < keywords.length; i++) {
            const mid = variables.ue_mid;
            const requestId = variables.ue_id;
            const sessionId = variables.ue_sid;
            const alias = "aps";
            const prefix = keywords[i].value;
            const limit = 11;
            let link = `https://completion.${hostname.replace(
              "www.",
              ""
            )}/api/2017/suggestions?session-id=${sessionId}&request-id=${requestId}&mid=${mid}&alias=${alias}&prefix=${prefix}&limit=${limit}`;
            promises.push(
              // HTTP request to get product details
              $.get(link, function (res) {
                res.suggestions.forEach((keyword) => {
                  if (
                    recommendedKeywords.filter(
                      (item) => item.value == keyword.value
                    ).length <= 0 &&
                    keywords.filter((item) => item.value == keyword.value)
                      .length <= 0
                  ) {
                    recommendedKeywords.push({
                      value: keyword.value,
                      link: `https://${hostname}/s?k=${keyword.value.replace(
                        / /g,
                        "+"
                      )}&crid=${res.responseId}&sprefix=${res.prefix.replace(
                        / /g,
                        "+"
                      )}&ref=${keyword.refTag}`,
                    });
                  }
                });
              }).fail(function (error) {
                // console.log("error", error);
              })
            );
          }

          function getSuggestionsURL(e, n, a) {
            var t = "amazon.com",
              o = "1";
            location.hostname.indexOf("amazon.ca") > 0 &&
              ((t = "amazon.com"), (o = "7")),
              location.hostname.indexOf("amazon.co.uk") > 0 &&
                ((t = "amazon.co.uk"), (o = "3")),
              location.hostname.indexOf("amazon.de") > 0 &&
                ((t = "amazon.co.uk"), (o = "4")),
              location.hostname.indexOf("amazon.fr") > 0 &&
                ((t = "amazon.co.uk"), (o = "5")),
              location.hostname.indexOf("amazon.it") > 0 &&
                ((t = "amazon.co.uk"), (o = "35691")),
              location.hostname.indexOf("amazon.es") > 0 &&
                ((t = "amazon.co.uk"), (o = "44551")),
              location.hostname.indexOf("amazon.com.mx") > 0 &&
                ((t = "amazon.com"), (o = "771770"));
            var s =
              "https://completion." +
              t +
              "/search/complete?mkt=" +
              o +
              "&q=" +
              escape(e) +
              "&qs=" +
              escape(n) +
              "&" +
              a;
            return s;
          }

          var a = $("#searchDropdownBox").val();

          var t = [];
          var n = searchedText;
          t.push(getSuggestionsURL(n, "", a));
          t.push(getSuggestionsURL(" ", n.trim(), a));
          t.push(getSuggestionsURL(n.trim() + " ", "", a));
          var o = n.split(" ");
          if (o.length >= 2) {
            for (var s = [], r = 1; r < o.length; r++) s.push(o[r]);
            t.push(getSuggestionsURL(o[0] + " ", " " + s.join(" "), a));
          }
          t.push(getSuggestionsURL(n + " ", "for ", a));
          t.push(getSuggestionsURL(n + " ", "and ", a));
          t.push(getSuggestionsURL(n + " ", "with ", a));

          for (let i = 0; i < t.length; i++) {
            console.log(t[i]);
            promises.push(
              // Promise(function (e, n) {
              chrome.runtime.sendMessage(
                { command: "getUrl", url: t[i] },
                function (res) {
                  console.log("data", res);
                  console.log("\n\n\n\n\n");
                  JSON.parse(res)[1].forEach((keyword) => {
                    console.log("keyword", keyword);
                    if (
                      recommendedKeywords.filter(
                        (item) => item.value == keyword
                      ).length <= 0 &&
                      keywords.filter((item) => item.value == keyword).length <=
                        0
                    ) {
                      recommendedKeywords.push({
                        value: keyword,
                        link: `https://${hostname}/s?k=${keyword.replace(
                          / /g,
                          "+"
                        )}`,
                      });
                    }
                  });
                }
              )
            );
          }

          // Done all promise
          Promise.all(promises).then(function () {
            console.log(recommendedKeywords);
            renderList(keywords, recommendedKeywords);
          });
        }
      }, 1000);
    });
  });
}

try {
  renderAnalysisTable();
} catch (error) {
  // console.log("catch", error);
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  chrome.storage.local.set(
    {
      [uniqueId + "_isEnable"]: msg.isEnable,
    },
    function () {
      if (chrome.runtime.lastError) {
        console.log("Error Storing 2: ", chrome.runtime.lastError.message);
      }

      location.reload();
    }
  );
});
