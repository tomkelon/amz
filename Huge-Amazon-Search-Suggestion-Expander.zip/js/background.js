chrome.runtime.onMessage.addListener(function (e, t, n) {
	return 'getUrl' == e.command
		? (fetch(e.url, { method: 'GET' })
				.then(function (e) {
					e.text().then(function (e) {
						console.log(e), n(e);
					});
				})
				['catch'](function (e) {
					console.error(e);
				}),
		  !0)
		: void ('saveKeywords' == e.command);
});
