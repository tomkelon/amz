chrome.storage.local.set({ version: 3 });

// let currentAmzTab = 0;

// chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
//   if (msg === "amz-bsr-cs") {
//     currentAmzTab = sender.tab.id;
//   }
// });

// chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
//   // changeInfo object: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/tabs/onUpdated#changeInfo
//   // status is more reliable (in my case)
//   // use "alert(JSON.stringify(changeInfo))" to check what's available and works in your case

//   if (tabId === currentAmzTab && changeInfo.url) {
//     chrome.tabs.sendMessage(tabId, {
//       message: "TabUpdated",
//     });
//     console.log(tabId);
//     console.log(changeInfo);
//     chrome.tabs.update(tabId, { url: changeInfo.url });
//   }

//   // if (changeInfo.status === 'complete') {
//   //   chrome.tabs.sendMessage(tabId, {
//   //     message: 'TabUpdated'
//   //   });
//   // }
// });
